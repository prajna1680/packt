module deskdroid.shared {
    exports com.steeplesoft.deskdroid.model;
}