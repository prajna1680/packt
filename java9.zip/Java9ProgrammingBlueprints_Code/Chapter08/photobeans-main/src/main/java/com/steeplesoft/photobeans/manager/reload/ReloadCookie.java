package com.steeplesoft.photobeans.manager.reload;

/**
 *
 * @author jason
 */
public class ReloadCookie {
    
}
