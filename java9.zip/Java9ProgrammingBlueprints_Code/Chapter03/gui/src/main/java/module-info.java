module dupefind.gui {
    requires dupefind.lib;
    requires java.logging;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
}