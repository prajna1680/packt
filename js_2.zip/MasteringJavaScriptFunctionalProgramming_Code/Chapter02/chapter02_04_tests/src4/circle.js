const PI = 3.14159265358979;
const circleArea = (r) => PI * Math.pow(r, 2);
