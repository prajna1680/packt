const isOldEnough3 = (currentYear, birthYear) => birthYear <= currentYear-18;
