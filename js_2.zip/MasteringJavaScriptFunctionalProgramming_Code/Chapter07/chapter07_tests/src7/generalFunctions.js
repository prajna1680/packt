const make3 = (a, b, c) => String(100*a + 10*b + c);

const sum = (...args) => args.reduce((x,y) => x+y, 0);

const nonsense = (a,b,c,d,e) => `${a}/${b}/${c}/${d}/${e}`;

