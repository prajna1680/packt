# Rebelcon 2017
This is the example used on the talk from David Gonzalez on RebelCon
2017.

## Contact me

David Gonzalez - david.gonzalez@nearform.com

Twitter - @dagonzago

https://developers.google.com/experts/people/david-gonzalez-gonzalez
