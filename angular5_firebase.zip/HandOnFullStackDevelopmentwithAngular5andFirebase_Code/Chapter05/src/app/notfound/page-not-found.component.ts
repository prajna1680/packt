import {Component} from '@angular/core';

@Component({
    selector: 'app-friends-page-not-found',
    template: '<h2>Page not found</h2>'
})
export class PageNotFoundComponent {
}
