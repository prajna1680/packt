export const USERS_CHILD = '/users';
export const FRIENDS_CHILD = 'friends';
export const USER_DETAILS_CHILD = 'user-details';

