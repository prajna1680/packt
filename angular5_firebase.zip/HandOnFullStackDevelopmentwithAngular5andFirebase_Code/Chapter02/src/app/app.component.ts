import {Component} from '@angular/core';

@Component({
    selector: 'app-friends',
    styleUrls: ['app.component.scss'],
    templateUrl: './app.component.html',
})
export class AppComponent {
}
