export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyDT5XVZncjAXKjaNp-Pm9UrX9V-HKduxT8',
    authDomain: 'friends-staging.firebaseapp.com',
    databaseURL: 'https://friends-staging.firebaseio.com',
    projectId: 'friends-staging',
    storageBucket: 'friends-staging.appspot.com',
    messagingSenderId: '807434545532'
  }
};
