"use strict";
exports.environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyCkoU9eRZ94pyiMJ1ZQSGT0W8ca01l-gaw',
        authDomain: 'friends-4d4fa.firebaseapp.com',
        databaseURL: 'https://friends-4d4fa.firebaseio.com',
        projectId: 'friends-4d4fa',
        storageBucket: '',
        messagingSenderId: '321535044959'
    }
};
//# sourceMappingURL=environment.js.map