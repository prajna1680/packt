require('babel-core/register');
require('babel-polyfill');
require('./server');