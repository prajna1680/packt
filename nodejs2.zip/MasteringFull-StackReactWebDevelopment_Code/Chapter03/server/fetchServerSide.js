export default () => {
  return {
      "article":
    {
      "0": {
      "articleTitle": "SERVER-SIDE Lorem ipsum - article one",
      "articleContent":"SERVER-SIDE Here goes the content of the article"
    },
      "1": {
      "articleTitle":"SERVER-SIDE Lorem ipsum - article two",
      "articleContent":"SERVER-SIDE Sky is the limit, the content goes here."
      }
    }
  }
}