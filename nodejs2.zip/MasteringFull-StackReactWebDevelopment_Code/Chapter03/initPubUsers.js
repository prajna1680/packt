[
  {
    "username" : "admin",
    "password" :
    "c5a0df4e293953d6048e78bd9849ec0ddce811f0b29f72564714e474615a7852",
    "firstName" : "Kamil",
    "lastName" : "Przeorski",
    "email" : "kamil@mobilewebpro.pl",
    "role" : "admin",
    "verified" : false,
    "imageUrl" : "http://lorempixel.com/100/100/people/"
  }
]