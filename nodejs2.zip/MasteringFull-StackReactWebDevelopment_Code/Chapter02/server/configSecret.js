export default {
  'secret': process.env.JWT_SECRET || 'devSecretGoesHere'
}