### Collections

A set of utilities for managing collections.