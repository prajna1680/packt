### FocusKeyManager
`ListKeyManager` manages the focus of an item based on keyboard interaction.