package com.tomekl007.cassandra.model

case class UserDataJoined(key: String, value: Int, age: Int)
