package com.tomekl007.cassandra.model

case class UserData(key: String, age: Int)
