kubectl delete deploy/web
kubectl delete svc/web
kubectl delete statefulset/db
kubectl delete svc/db
