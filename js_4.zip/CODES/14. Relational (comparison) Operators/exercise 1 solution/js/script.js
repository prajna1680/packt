var variableToCheck = 5;
var staticComparedValue = 3;

alert("Is " + variableToCheck + " lower than " + comparedValue + ": " + (variableToCheck < staticComparedValue));