
var temperatureCelsius = 32; //sooo hot ;)

var temperatureFahrenheit = (temperatureCelsius * 9/5) + 32;
var temperatureKelvin = temperatureCelsius + 273.15;

alert("The inputted temperature in Celsius: " + temperatureCelsius);
alert("Converted to Fahrenheit: " + temperatureFahrenheit);
alert("Converted to Kelvin: " + temperatureKelvin);