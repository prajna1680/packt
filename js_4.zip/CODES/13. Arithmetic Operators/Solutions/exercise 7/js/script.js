var firstNumber = 24;
var secondNumber = 15;

var divisionRemainder = firstNumber % secondNumber;

alert("Division remainder result: " + divisionRemainder);
