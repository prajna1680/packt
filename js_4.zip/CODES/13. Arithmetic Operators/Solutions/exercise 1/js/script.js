
var lengthInches = 20;

var lengthCentimeters = lengthInches * 2.54;

alert(lengthInches + " inches is equal to " + lengthCentimeters + " centimeters.");

